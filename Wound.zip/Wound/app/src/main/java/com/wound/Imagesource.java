package com.wound;

import java.util.Iterator;

import android.os.Bundle;
import android.os.DropBoxManager.Entry;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Imagesource extends MainActivity {
	Bitmap map;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.imagesource);
		
		TextView t1=(TextView)findViewById(R.id.tpath);
		Bundle be=getIntent().getExtras();
		t1.setText(be.getCharSequence("path"));
		
		
	//	Button b1=(Button)findViewById(R.id.black);
	//	Button b2=(Button)findViewById(R.id.grayscale);
		// sample = BitmapFactory.decodeResource(getResources(),
	       //     R.drawable.ic_launcher);

		        ImageView orginalImageView = (ImageView) findViewById(R.id.image);
		      
		        map= BitmapFactory.decodeFile(t1.getText().toString());
		        orginalImageView.setImageBitmap(map);
		/*        b1.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						ImageView blackImageView = (ImageView) findViewById(R.id.blackimage);
						
						blackImageView.setBackgroundDrawable(new BitmapDrawable(
				                convertColorIntoBlackAndWhiteImage(map, 9)));
						
					}
				});
		      /*  b2.setOnClickListener(new View.OnClickListener() {
					
					@Override
					public void onClick(View v) {
						ImageView blackImageView = (ImageView) findViewById(R.id.blackimage);
					blackImageView.setBackgroundDrawable(new BitmapDrawable(
							applySaturationFilter(sample, 1)));
					
							
					}
				});*/
		    }


		    private Bitmap convertColorIntoBlackAndWhiteImage(Bitmap orginalBitmap,int level) {
		    		//hue image
		    	
		    	    // get image size
		    	    int width = orginalBitmap.getWidth();
		    	    int height = orginalBitmap.getHeight();
		    	    int[] pixels = new int[width * height];
		    	    float[] HSV = new float[3];
		    	    // get pixel array from source
		    	    orginalBitmap.getPixels(pixels, 0, width, 0, 0, width, height);
		    	     
		    	    int index = 0;
		    	    // iteration through pixels
		    	    for(int y = 0; y < height; ++y) {
		    	        for(int x = 0; x < width; ++x) {
		    	            // get current index in 2D-matrix
		    	            index = y * width + x;              
		    	            // convert to HSV
		    	            Color.colorToHSV(pixels[index], HSV);
		    	            // increase <span class="ywxl4" id="ywxl4_6">Saturation</span> level
		    	            HSV[0] *= level;
		    	            HSV[0] = (float) Math.max(0.0, Math.min(HSV[0], 360.0));
		    	            // take color back
		    	            pixels[index] |= Color.HSVToColor(HSV);
		    	        }
		    	    }
		    	    // output bitmap                
		    	    map = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
		    	    map.setPixels(pixels, 0, width, 0, 0, width, height);
		    	    return map;       
		    	}

		    	//mirror image
		    	/*Matrix mat=new Matrix();
		    	//mat.preScale(-1.0f, 1.0f);
          
                // return transformed image
                
		    	 ColorMatrix colorMatrix = new ColorMatrix(new float[]{
		    			 0,0,0,1,0,
		    			 0,0,0,0,0,
		    			 0,0,0,0,0,
		    			 0,0,0,1,0
				           
				            });
		       // colorMatrix.setSaturation(0);

		        ColorMatrixColorFilter colorMatrixFilter = new ColorMatrixColorFilter(
		                colorMatrix);
		      

		        Bitmap blackAndWhiteBitmap = orginalBitmap.copy(
		                Bitmap.Config.ARGB_8888, true);

		        Paint paint = new Paint();
		        paint.setColorFilter(colorMatrixFilter);

		        Canvas canvas = new Canvas(blackAndWhiteBitmap);
		        canvas.drawBitmap(blackAndWhiteBitmap, 0, 0, paint);

		        //return blackAndWhiteBitmap;
		        		return Bitmap.createBitmap(orginalBitmap, 0, 0, orginalBitmap.getWidth(), orginalBitmap.getHeight(), mat, true);
		    }
		/*    public Bitmap toGrayscale(Bitmap bmpOriginal)
		    {        
		        int width, height;
		        height = bmpOriginal.getHeight();
		        width = bmpOriginal.getWidth();    

		        Bitmap bmpGrayscale = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
		        Canvas c = new Canvas(bmpGrayscale);
		        Paint paint = new Paint();
		        ColorMatrix cm = new ColorMatrix(new float[]{
			    		0.5f,0.5f,0.5f,0,0,
			            0.5f,0.5f,0.5f,0,0,
			            0.5f,0.5f,0.5f,0,0,
			            0,0,0,1,0,0,
			            0,0,0,0,1,0
			            });
		        cm.setSaturation(0);
		        ColorMatrixColorFilter f = new ColorMatrixColorFilter(cm);
		        paint.setColorFilter(f);
		        c.drawBitmap(bmpOriginal, 0, 0, paint);
		        return bmpGrayscale;
		    }
		   /* public void onDraw(Canvas canvas) {
				Paint paint = new Paint();
	 
				canvas.drawColor(Color.YELLOW);
	 
	 
				// you need to insert a image flower_blue into res/drawable folder
	 
				paint.setFilterBitmap(true);
				canvas.drawBitmap(sample, 10, 10, paint);
				int width, height;
	 
			    ColorMatrix cm = new ColorMatrix();
			    		
			    cm.setSaturation(0);
			    ColorMatrixColorFilter f = new ColorMatrixColorFilter(cm);
			    paint.setColorFilter(f);
			    int h = sample.getHeight();
				//canvas.drawBitmap(bitmapOrg, 10, 10, paint);
				canvas.drawBitmap(sample, 10, 10 + h + 10, paint);
	 
			}
		    public static final Bitmap changeToSketch(Bitmap src,int type,int threshold) {
		          int width = src.getWidth();
		        int height = src.getHeight();
		        Bitmap result = Bitmap.createBitmap(width, height, src.getConfig());

		        int A, R, G, B;
		        int sumR, sumG, sumB;
		        int[][] pixels = new int[3][3];
		        for(int y = 0; y < height - 2; ++y) {
		            for(int x = 0; x < width - 2; ++x) {
		           //      get pixel matrix
		                      for(int i = 0; i < 3; ++i) {
		                    for(int j = 0; j < 3; ++j) {
		                        pixels[i][j] = src.getPixel(x + i, y + j);
		                    }
		                }
		            // get alpha of center pixel
		                A = Color.alpha(pixels[1][1]);
		                // init color sum
		                sumR = sumG = sumB = 0;
		                sumR = (type*Color.red(pixels[1][1])) - Color.red(pixels[0][0]) - Color.red(pixels[0][2]) - Color.red(pixels[2][0]) - Color.red(pixels[2][2]);
		                sumG = (type*Color.green(pixels[1][1])) - Color.green(pixels[0][0]) - Color.green(pixels[0][2]) - Color.green(pixels[2][0]) - Color.green(pixels[2][2]);
		                sumB = (type*Color.blue(pixels[1][1])) - Color.blue(pixels[0][0]) - Color.blue(pixels[0][2]) - Color.blue(pixels[2][0]) - Color.blue(pixels[2][2]);
		                // get final Red
		                R = (int)(sumR  + threshold);
		                if(R < 0) { R = 0; }
		                else if(R > 255) { R = 255; }
		                // get final Green
		                G = (int)(sumG  + threshold);
		                if(G < 0) { G = 0; }
		                else if(G > 255) { G = 255; }
		                // get final Blue
		                B = (int)(sumB  + threshold);
		                if(B < 0) { B = 0; }
		                else if(B > 255) { B = 255; }

		                result.setPixel(x + 1, y + 1, Color.argb(A, R, G, B));
		            }
		        }
		        return result;
		      }
		             
		    public static Bitmap applySaturationFilter(Bitmap source, int level) {
				// get image size
				int width = source.getWidth();
				int height = source.getHeight();
				int[] pixels = new int[width * height];
				float[] HSV = new float[3];
				// get pixel array from source
				source.getPixels(pixels, 0, width, 0, 0, width, height);

				int index = 0;
				// iteration through pixels
				for(int y = 0; y < height; ++y) {
					for(int x = 0; x < width; ++x) {
						// get current index in 2D-matrix
						index = y * width + x;
						// convert to HSV
						Color.colorToHSV(pixels[index], HSV);
						// increase Saturation level
						HSV[1] *= level;
						HSV[1] = (float) Math.max(0.0, Math.min(HSV[1], 1.0));
						// take color back
					}				pixels[index] |= Color.HSVToColor(HSV);
				}
				 Bitmap bmOut = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
				    bmOut.setPixels(pixels, 0, width, 0, 0, width, height);
				    return bmOut;*/
		
		    
		   /* public class Histogram {
		        private final static int MIN_AMPLITUDE = 40000;
		        //private final static int MAX_AMPLITUDE = 3200000;
		        private final static int MAX_AMPLITUDE = 20000;
		        private final static int MAX_LN_AMP = 30;
		        
		        private long GetAmplitudeScreenHeight(Canvas canvas, double amplitude, Rect histogram_rect) {
		                return Math.round(amplitude / MAX_AMPLITUDE * histogram_rect.height());
		                //return Math.round(Math.log(amplitude) / MAX_LN_AMP * histogram_rect.height());
		        }
		        

		        public boolean DrawHistogram(Canvas canvas, Rect rect, FreqResult fr) {
		                if (fr.frequencies == null) {
		                        return false;
		                }
		                
		                Paint paint = new Paint();
		                // Draw border.
		                paint.setARGB(80, 200, 200, 200);
		                paint.setStyle(Paint.Style.STROKE);
		                canvas.drawRect(rect, paint);
		                
		                // Draw threshold.
		                paint.setARGB(180, 200, 0, 0);
		                //final long threshold_screen_height = GetAmplitudeScreenHeight(canvas, MIN_AMPLITUDE, rect);
		                //final long threshold_screen_height = GetAmplitudeScreenHeight(canvas, Math.sqrt(fr.noiseLevel), rect);
		                final long threshold_screen_height = GetAmplitudeScreenHeight(canvas, fr.noiseLevel, rect);
		                canvas.drawLine(rect.left, rect.bottom - threshold_screen_height, rect.right, rect.bottom - threshold_screen_height, paint);

		                // Draw histogram.
		                paint.setARGB(255, 140, 140, 140);

		                boolean above_threshold = false;
		                int column_no = 0;
		                
		                float deadFrequencyPixels = rect.width() * PitchDetector.MIN_FREQUENCY / PitchDetector.SPECTRUM_HZ;
		                float remainingWidth = rect.width() - deadFrequencyPixels;
		                Iterator<Entry> it = fr.frequencies.entrySet().iterator();
		                while (it.hasNext()) {
		                        Entry entry = it.next();
		                        // double frequency = entry.getKey();
		                        final double amplitude = Math.min(entry.getValue(), MAX_AMPLITUDE);
		                        final long height = GetAmplitudeScreenHeight(canvas, amplitude, rect);
		                        if (amplitude > MIN_AMPLITUDE) {
		                                above_threshold = true;
		                        }
		                        canvas.drawRect(
		                                        deadFrequencyPixels + rect.left + remainingWidth * column_no / fr.frequencies.size(),
		                                        rect.bottom - height, 
		                                        deadFrequencyPixels + rect.left + remainingWidth * (column_no + 1) / fr.frequencies.size(),
		                                        rect.bottom, 
		                                        paint);
		                        column_no++;
		                }
		                return above_threshold;
		        }
		}*/

}
		
		


	

	

