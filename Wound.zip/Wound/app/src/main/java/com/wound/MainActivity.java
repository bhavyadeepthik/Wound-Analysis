package com.wound;

import java.io.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.ContactsContract.Data;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;
public class MainActivity extends Activity {

	private Uri uri;
	Bitmap imag;
	ImageView im;

	ImageButton bro,upl,capt;

	EditText e1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		e1=(EditText)findViewById(R.id.fileText1);
		bro=(ImageButton)findViewById(R.id.ffbrowse);
		upl=(ImageButton)findViewById(R.id.ffupload);
		capt=(ImageButton)findViewById(R.id.capture);
		bro.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				Intent b1=new Intent(MainActivity.this,FileBrowser.class);
				startActivityForResult(b1,1);


			}
		});

		upl.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {

				Toast.makeText(getBaseContext(), "open welcome ", Toast.LENGTH_SHORT).show();
				Intent main=new Intent(MainActivity.this,Collection.class);
				Bundle be=new Bundle();
				be.putString("path", e1.getText().toString());
				main.putExtras(be);
				startActivity(main);
			}

		});
		capt.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				captureimage();

			}
		});
	}
	private void captureimage(){

		StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
		StrictMode.setVmPolicy(builder.build());
		Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

		uri = Uri.fromFile(new File(Environment
				.getExternalStorageDirectory(), "image_"
				+ String.valueOf(System.currentTimeMillis())
				+ ".jpg"));


		e1.setText( Uri.parse("android.resource://com.your.package/raw/wound.jpg").toString());

		intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
				uri);

		try {
			intent.putExtra("return-data", true);

			startActivityForResult(intent,0);
		} catch (ActivityNotFoundException e) {
			e.printStackTrace();
		}
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if(resultCode==RESULT_OK){


			Toast.makeText(getBaseContext(), "imageCaptured",Toast.LENGTH_LONG).show();

		}else if(resultCode==RESULT_CANCELED){
			Toast.makeText(getBaseContext(), "user cancelled",Toast.LENGTH_LONG).show();
		}else{
			Toast.makeText(getBaseContext(), "Sorry Failed to capture image",Toast.LENGTH_LONG).show();
		}
			//Toast.makeText(getApplicationContext(), data.getStringExtra("SelectedFileName"), Toast.LENGTH_LONG).show();

			im=(ImageView)findViewById(R.id.captureimage);
			InputStream bm = getResources().openRawResource(R.raw.wound);
			BufferedInputStream bufferedInputStream = new BufferedInputStream(bm);
			Bitmap bmp = BitmapFactory.decodeStream(bufferedInputStream);
			int nh = (int) (bmp.getHeight() * (512.0 / bmp.getWidth()));
			bmp = Bitmap.createScaledBitmap(bmp, 512, nh, true);
			im.setImageBitmap(bmp);


	}
}



																																																																																