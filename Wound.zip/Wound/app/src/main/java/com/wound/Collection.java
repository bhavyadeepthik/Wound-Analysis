package com.wound;

import java.util.Iterator;
import java.util.Map.Entry;
import java.io.IOException;
import java.lang.Runnable;
import java.lang.Thread;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.locks.ReentrantLock;


import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder.AudioSource;
import android.os.AsyncTask;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class Collection extends MainActivity {
	Button hue,satur,inver,gray,histo,mir,pix;
	Bitmap mirr,inverse,Grayscal,Hu,sobel,histogram;
	ImageView orginalImageView;
	TextView t1;
	final Context context = this;
	 @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.collection);
	         t1=(TextView)findViewById(R.id.imageid);
			Bundle be=getIntent().getExtras();
			t1.setText(be.getCharSequence("path"));
		
			orginalImageView = (ImageView) findViewById(R.id.collectionimage); 
	        mirr= BitmapFactory.decodeFile(t1.getText().toString());
	        inverse= BitmapFactory.decodeFile(t1.getText().toString());
	        Hu= BitmapFactory.decodeFile(t1.getText().toString());
	        sobel= BitmapFactory.decodeFile(t1.getText().toString());
	        histogram= BitmapFactory.decodeFile(t1.getText().toString());
	        Grayscal= BitmapFactory.decodeFile(t1.getText().toString());
	        orginalImageView.setImageBitmap(mirr);
	        orginalImageView.setImageBitmap(inverse);
	        orginalImageView.setImageBitmap(sobel);
	        hue=(Button)findViewById(R.id.hue);
	        satur=(Button)findViewById(R.id.Saturation);
	        inver=(Button)findViewById(R.id.Inverse);
	        gray=(Button)findViewById(R.id.Grayscale);
	        histo=(Button)findViewById(R.id.Histogram);
	        mir=(Button)findViewById(R.id.mirror);
	        satur.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					final Dialog dialog = new Dialog(context);
					dialog.setContentView(R.layout.custom);
					dialog.setTitle("sobel image");

					// set the custom dialog components - text, image and button
					ImageView image = (ImageView) dialog.findViewById(R.id.image);
					image.setBackgroundDrawable(new BitmapDrawable(
			                 sobel(sobel)));

					Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
					// if button is clicked, close the custom dialog
					dialogButton.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							dialog.dismiss();
						}
					});

					dialog.show();
				}



					
				
			});
	        pix=(Button)findViewById(R.id.pixel);
	        pix.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					
					DisplayMetrics metrics=new DisplayMetrics();
					int c=orginalImageView.getHeight();
					int d=orginalImageView.getWidth();
					//metrics.
					
					Matrix g=orginalImageView.getImageMatrix();
					//String e=Integer.toString(c);
					//String f=Integer.toString(d);
					
					
					Toast.makeText(getApplicationContext(),"Height of image in pixels"+g+"width of image in pixels", Toast.LENGTH_LONG).show();
					
				}
			});
	        gray.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					final Dialog dialog = new Dialog(context);
					dialog.setContentView(R.layout.custom);
					dialog.setTitle("GrayScale image");

					// set the custom dialog components - text, image and button
					ImageView image = (ImageView) dialog.findViewById(R.id.image);
					image.setBackgroundDrawable(new BitmapDrawable(
			                convertGrayScaleimage(Grayscal)));

					Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
					// if button is clicked, close the custom dialog
					dialogButton.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							dialog.dismiss();
						}
					});

					dialog.show();
				}


					
				
			});
	        histo.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					Intent a=new Intent(Collection.this,Histogram.class);
					Bundle be=new Bundle();
					t1=(TextView)findViewById(R.id.imageid);
					be.putString("path", t1.getText().toString());
					a.putExtras(be);
					startActivity(a);
					
					
				}
			});
	        inver.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					
					final Dialog dialog = new Dialog(context);
					dialog.setContentView(R.layout.custom);
					dialog.setTitle("Negative image");

					// set the custom dialog components - text, image and button
					ImageView image = (ImageView) dialog.findViewById(R.id.image);
					image.setBackgroundDrawable(new BitmapDrawable(
			                convertColorIntoBlackAndWhiteImage(inverse)));

					Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
					// if button is clicked, close the custom dialog
					dialogButton.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							dialog.dismiss();
						}
					});

					dialog.show();
				}

					
				
			});
	 
	       mir.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				final Dialog dialog = new Dialog(context);
				dialog.setContentView(R.layout.custom);
				dialog.setTitle("Mirror image");

				// set the custom dialog components - text, image and button
				ImageView image = (ImageView) dialog.findViewById(R.id.image);
				image.setBackgroundDrawable(new BitmapDrawable(
		                mirror(mirr)));

				Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
				// if button is clicked, close the custom dialog
				dialogButton.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						dialog.dismiss();
					}
				});

				dialog.show();
			}
				
			
		});
	       hue.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
			
				final Dialog dialog = new Dialog(context);
				dialog.setContentView(R.layout.custom);
				dialog.setTitle("sepia image");
				

				// set the custom dialog components - text, image and button
				ImageView image = (ImageView) dialog.findViewById(R.id.image);
				image.setBackgroundDrawable(new BitmapDrawable(
						ConvertToSepia(Hu)));

				Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
				// if button is clicked, close the custom dialog
				dialogButton.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						dialog.dismiss();
					}
				});

				dialog.show();
			}

			
		});
	       
	 }
	
		 public Bitmap ConvertToSepia(Bitmap Hu){
			 ColorMatrix sepiaMatrix =new ColorMatrix();
			 float[] sepMat={0.189f, 0.769f, 0.393f, 0f,0,0.168f, 0.686f, 0.349f, 0f,0,0.131f, 0.534f, 0.272f, 0f,0,0.000f, 0.000f, 0.000f, 1f,1f};
			 sepiaMatrix.set(sepMat);
			 final ColorMatrixColorFilter colorFilter= new ColorMatrixColorFilter(sepiaMatrix);
			 Bitmap rBitmap = Hu.copy(Bitmap.Config.ARGB_8888, true);
			 Paint paint=new Paint();
			 paint.setColorFilter(colorFilter);
			 Canvas myCanvas =new Canvas(rBitmap);
			 myCanvas.drawBitmap(rBitmap, 0, 0, paint);
			 return rBitmap;
			 }
	 private Bitmap mirror(Bitmap orginalBitmap){
		 Matrix mat=new Matrix();
	    	mat.preScale(-1.0f, 1.0f);
         
         // return transformed image
         return Bitmap.createBitmap(orginalBitmap, 0, 0, orginalBitmap.getWidth(), orginalBitmap.getHeight(), mat, true);

	 }
	 
	 private Bitmap convertColorIntoBlackAndWhiteImage(Bitmap orginalBitmap) {
	        ColorMatrix colorMatrix = new ColorMatrix(new float[]{
	        		
		    		-1,0,0,0,255,
		            0,-1,0,0,255,
		            0,0,-1,0,255,
		            0,0,0,1,255
		           
		            });
	        //colorMatrix.setSaturation(0);

	        ColorMatrixColorFilter colorMatrixFilter = new ColorMatrixColorFilter(
	                colorMatrix);

	        inverse= orginalBitmap.copy(
	                Bitmap.Config.ARGB_8888, true);

	        Paint paint = new Paint();
	        paint.setColorFilter(colorMatrixFilter);

	        Canvas canvas = new Canvas(inverse);
	        canvas.drawBitmap(inverse, 0, 0, paint);

	        return inverse ;
	        
	    }
	 

	 private Bitmap convertGrayScaleimage(Bitmap Grayscal) {
	        ColorMatrix colorMatrix = new ColorMatrix();
	        colorMatrix.setSaturation(0);

	        ColorMatrixColorFilter colorMatrixFilter = new ColorMatrixColorFilter(
	                colorMatrix);

	        Bitmap blackAndWhiteBitmap = Grayscal.copy(
	                Bitmap.Config.ARGB_8888, true);

	        Paint paint = new Paint();
	        paint.setColorFilter(colorMatrixFilter);

	        Canvas canvas = new Canvas(blackAndWhiteBitmap);
	        canvas.drawBitmap(blackAndWhiteBitmap, 0, 0, paint);

	        return blackAndWhiteBitmap;
	    }
	 private Bitmap sobel(Bitmap orginalBitmap) {
	        ColorMatrix colorMatrix = new ColorMatrix(new float[]{
	        		
		    		1.4f,0,0,82.5f,0,
		            0,1.4f,0,0,0,
		            0,0,1,0,0,
		            0,0,0,1,0
		           
		            });
	        //colorMatrix.setSaturation(0);

	        ColorMatrixColorFilter colorMatrixFilter = new ColorMatrixColorFilter(
	                colorMatrix);

	        sobel= orginalBitmap.copy(
	                Bitmap.Config.ARGB_8888, true);

	        Paint paint = new Paint();
	        paint.setColorFilter(colorMatrixFilter);

	        Canvas canvas = new Canvas(sobel);
	        canvas.drawBitmap(sobel, 0, 0, paint);

	        return sobel ;
	        
	    }

	 
	    }
	 


